const express = require('express');
const router = express.Router();
const Cart = require('../models/Cart');
const { auth } = require('../middleware/authMiddleware');

router.get('/', auth, async (req, res) => {
  const cart = await Cart.findOne({ userId: req.user.id });
  res.json(cart || { items: [] });
});

router.post('/add', auth, async (req, res) => {
  const { productId, quantity } = req.body;
  let cart = await Cart.findOne({ userId: req.user.id });

  if (!cart) {
    cart = await Cart.create({ userId: req.user.id, items: [{ productId, quantity }] });
  } else {
    const index = cart.items.findIndex(item => item.productId.equals(productId));
    if (index > -1) cart.items[index].quantity += quantity;
    else cart.items.push({ productId, quantity });
    await cart.save();
  }

  res.json(cart);
});

router.put('/update', auth, async (req, res) => {
  const { productId, quantity } = req.body;
  const cart = await Cart.findOne({ userId: req.user.id });
  const item = cart.items.find(i => i.productId.equals(productId));
  if (item) item.quantity = quantity;
  await cart.save();
  res.json(cart);
});

router.delete('/remove/:productId', auth, async (req, res) => {
  const cart = await Cart.findOne({ userId: req.user.id });
  cart.items = cart.items.filter(i => !i.productId.equals(req.params.productId));
  await cart.save();
  res.json(cart);
});

module.exports = router;
