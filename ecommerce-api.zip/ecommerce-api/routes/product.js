const express = require('express');
const router = express.Router();
const Product = require('../models/Product');
const { auth, isAdmin } = require('../middleware/authMiddleware');

router.get('/', async (req, res) => {
  const { page = 1, limit = 5, search = '' } = req.query;
  const query = search ? { name: { $regex: search, $options: 'i' } } : {};
  const products = await Product.find(query)
    .skip((page - 1) * limit)
    .limit(Number(limit));
  res.json(products);
});

router.post('/', auth, isAdmin, async (req, res) => {
  const product = await Product.create(req.body);
  res.json(product);
});

router.put('/:id', auth, isAdmin, async (req, res) => {
  const updated = await Product.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(updated);
});

router.delete('/:id', auth, isAdmin, async (req, res) => {
  await Product.findByIdAndDelete(req.params.id);
  res.json({ msg: 'Deleted' });
});

module.exports = router;
